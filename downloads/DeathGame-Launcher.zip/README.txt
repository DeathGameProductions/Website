To run the Launcher you need the .NET Runtime 4.7.2 or later.
You can find a installer in the DotNet folder if you need to install it.

Have Fun :)